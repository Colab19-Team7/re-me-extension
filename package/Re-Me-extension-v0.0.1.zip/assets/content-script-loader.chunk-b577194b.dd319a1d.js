(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-b577194b.js")
    );
  })().catch(console.error);

})();
