(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-6a7a3eae.js")
    );
  })().catch(console.error);

})();
