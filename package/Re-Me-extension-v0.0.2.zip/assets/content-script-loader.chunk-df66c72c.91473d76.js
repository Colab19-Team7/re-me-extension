(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-df66c72c.js")
    );
  })().catch(console.error);

})();
